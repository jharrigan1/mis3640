#(25 points) Write a recursive function isPalindrome(string) that returns True if string is a palindrome, that is, a word that is the same when reversed. 
# Examples of palindromes are “deed”, “rotor”, or “aibohphobia”. 
# Hint: A word is a palindrome if the frst and last letters match and the remainder is also a palindrome.


inputStr = input('Please enter a string: ')
RevStr = reversed(inputStr)

def palindrome(s):
    if list(inputStr) == list(RevStr):
        print('True')
    else:
        print('This is not a palindrome')
palindrome(inputStr)