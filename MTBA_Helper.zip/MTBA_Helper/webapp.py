app.py:
from flask import Flask, render_template, request
from mbta_helper import find_stop_near

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        rtext = request.form['location']
        result = find_stop_near(rtext)

        if result:
            return render_template('results.html',rtext=rtext result=result)
        else:
            return render_template('UI.html', error=True)
    return render_template('UI.html', error=None)

if _name_ == '_main_':
    app.run()